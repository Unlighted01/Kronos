import os
from PIL import Image, ImageDraw

frames_dir = r"c:\Users\netne\Kronos\Kronos Project\kronos-godot\assets\sprites\ui\frames"
buttons_dir = r"c:\Users\netne\Kronos\Kronos Project\kronos-godot\assets\sprites\ui\buttons"
os.makedirs(frames_dir, exist_ok=True)
os.makedirs(buttons_dir, exist_ok=True)

# Palette Definitions (Mythology & Celestial Antiquity)
GOLD_HIGH = (255, 232, 138, 255)
GOLD_MID = (245, 195, 66, 255)
GOLD_DARK = (180, 130, 25, 255)
GOLD_SHADOW = (100, 70, 12, 255)

SLATE_DEEP = (11, 13, 24, 242)      # ~95% opacity for frosted mythic blur background peek
SLATE_MID = (22, 26, 44, 242)
SLATE_LIGHT = (36, 42, 70, 255)
SLATE_BORDER = (45, 52, 85, 255)

CYAN_GLOW = (79, 209, 232, 255)
CYAN_MID = (38, 140, 180, 255)

MARBLE_HIGH = (245, 242, 233, 255)
MARBLE_MID = (200, 195, 180, 255)
MARBLE_SHADOW = (110, 105, 95, 255)

# ==============================================================================
# 1. FRAME WINDOW 9-SLICE (24x24, Margins: 6, 6, 6, 6)
# ==============================================================================
w = 24
img_win = Image.new("RGBA", (w, w), (0, 0, 0, 0))
d_win = ImageDraw.Draw(img_win)

# Base background fill
d_win.rectangle([2, 2, w - 3, w - 3], fill=SLATE_DEEP)

# Outer gold rim
d_win.rectangle([1, 1, w - 2, w - 2], outline=GOLD_DARK)
d_win.line([(2, 1), (w - 3, 1)], fill=GOLD_HIGH)       # Top highlight
d_win.line([(1, 2), (1, w - 3)], fill=GOLD_HIGH)       # Left highlight
d_win.line([(w - 2, 2), (w - 2, w - 3)], fill=GOLD_SHADOW) # Right shadow
d_win.line([(2, w - 2), (w - 3, w - 2)], fill=GOLD_SHADOW) # Bottom shadow

# Inner engraved line
d_win.rectangle([3, 3, w - 4, w - 4], outline=SLATE_BORDER)

# Corner studs (Classical pyramids/rivets at corners 0..5)
for (cx, cy) in [(2, 2), (w - 4, 2), (2, w - 4), (w - 4, w - 4)]:
    d_win.rectangle([cx, cy, cx + 1, cy + 1], fill=GOLD_HIGH)
    d_win.point((cx + 1, cy + 1), fill=GOLD_SHADOW)

img_win.save(os.path.join(frames_dir, "frame_window_9slice.png"))

# ==============================================================================
# 2. FRAME PANEL 9-SLICE (20x20, Margins: 5, 5, 5, 5)
# ==============================================================================
w = 20
img_pnl = Image.new("RGBA", (w, w), (0, 0, 0, 0))
d_pnl = ImageDraw.Draw(img_pnl)

# Base fill
d_pnl.rectangle([2, 2, w - 3, w - 3], fill=SLATE_MID)

# Beveled antique brass border
d_pnl.rectangle([1, 1, w - 2, w - 2], outline=GOLD_DARK)
d_pnl.line([(2, 1), (w - 3, 1)], fill=GOLD_MID)
d_pnl.line([(1, 2), (1, w - 3)], fill=GOLD_MID)
d_pnl.line([(w - 2, 2), (w - 2, w - 3)], fill=GOLD_SHADOW)
d_pnl.line([(2, w - 2), (w - 3, w - 2)], fill=GOLD_SHADOW)

# Corner dots
d_pnl.point((2, 2), fill=GOLD_HIGH)
d_pnl.point((w - 3, 2), fill=GOLD_HIGH)
d_pnl.point((2, w - 3), fill=GOLD_MID)
d_pnl.point((w - 3, w - 3), fill=GOLD_SHADOW)

img_pnl.save(os.path.join(frames_dir, "frame_panel_9slice.png"))

# ==============================================================================
# 3. FRAME CARD 9-SLICE (16x16, Margins: 4, 4, 4, 4)
# ==============================================================================
w = 16
img_crd = Image.new("RGBA", (w, w), (0, 0, 0, 0))
d_crd = ImageDraw.Draw(img_crd)

# Dark slate card fill
d_crd.rectangle([1, 1, w - 2, w - 2], fill=(14, 17, 30, 240))

# Fine stone/gold rim
d_crd.rectangle([0, 0, w - 1, w - 1], outline=SLATE_BORDER)
d_crd.line([(1, 0), (w - 2, 0)], fill=SLATE_LIGHT)
d_crd.point((0, 0), fill=GOLD_MID)
d_crd.point((w - 1, 0), fill=GOLD_MID)
d_crd.point((0, w - 1), fill=GOLD_MID)
d_crd.point((w - 1, w - 1), fill=GOLD_MID)

img_crd.save(os.path.join(frames_dir, "frame_card_9slice.png"))

# ==============================================================================
# 4. FRAME DOCK 9-SLICE (20x20, Margins: 5, 5, 5, 5)
# ==============================================================================
w = 20
img_dck = Image.new("RGBA", (w, w), (0, 0, 0, 0))
d_dck = ImageDraw.Draw(img_dck)

# Deep obsidian fill
d_dck.rectangle([1, 1, w - 2, w - 2], fill=SLATE_DEEP)

# Top engraved golden rail
d_dck.line([(0, 0), (w - 1, 0)], fill=GOLD_MID)
d_dck.line([(0, 1), (w - 1, 1)], fill=GOLD_HIGH)
d_dck.line([(0, 2), (w - 1, 2)], fill=GOLD_SHADOW)

# Subtle side & bottom outline
d_dck.line([(0, 3), (0, w - 1)], fill=SLATE_BORDER)
d_dck.line([(w - 1, 3), (w - 1, w - 1)], fill=SLATE_BORDER)
d_dck.line([(0, w - 1), (w - 1, w - 1)], fill=SLATE_BORDER)

img_dck.save(os.path.join(frames_dir, "frame_dock_9slice.png"))

# ==============================================================================
# 5. FRAME MODAL 9-SLICE (24x24, Margins: 6, 6, 6, 6)
# ==============================================================================
w = 24
img_mod = Image.new("RGBA", (w, w), (0, 0, 0, 0))
d_mod = ImageDraw.Draw(img_mod)

d_mod.rectangle([2, 2, w - 3, w - 3], fill=(8, 10, 18, 250))
d_mod.rectangle([1, 1, w - 2, w - 2], outline=GOLD_MID)
d_mod.rectangle([3, 3, w - 4, w - 4], outline=GOLD_DARK)

# Filigree corners
for (cx, cy) in [(1, 1), (w - 3, 1), (1, w - 3), (w - 3, w - 3)]:
    d_mod.rectangle([cx, cy, cx + 1, cy + 1], fill=GOLD_HIGH)

img_mod.save(os.path.join(frames_dir, "frame_modal_9slice.png"))

# ==============================================================================
# 6. BUTTON STATES (20x20, Margins: 5, 5, 5, 5)
# ==============================================================================
def create_button(name, border_col, top_high, body_col, shadow_col, corner_col, shift=0):
    bw = 20
    b_img = Image.new("RGBA", (bw, bw), (0, 0, 0, 0))
    bd = ImageDraw.Draw(b_img)
    
    # Body fill
    bd.rectangle([1, 1, bw - 2, bw - 2], fill=body_col)
    
    # Outer border
    bd.rectangle([0, 0, bw - 1, bw - 1], outline=border_col)
    
    # Beveled edges
    bd.line([(1, 1 + shift), (bw - 2, 1 + shift)], fill=top_high)
    bd.line([(1, 1 + shift), (1, bw - 2)], fill=top_high)
    bd.line([(bw - 2, 1 + shift), (bw - 2, bw - 2)], fill=shadow_col)
    bd.line([(1, bw - 2), (bw - 2, bw - 2)], fill=shadow_col)
    
    # Corner rivets
    bd.point((1, 1 + shift), fill=corner_col)
    bd.point((bw - 2, 1 + shift), fill=corner_col)
    bd.point((1, bw - 2), fill=shadow_col)
    bd.point((bw - 2, bw - 2), fill=shadow_col)
    
    b_img.save(os.path.join(buttons_dir, name))

# Normal: Raised brass & slate
create_button("btn_mythic_normal.png", GOLD_DARK, GOLD_HIGH, (28, 33, 56, 255), GOLD_SHADOW, GOLD_MID, shift=0)

# Hover: Radiant gold & cyan focus glow
create_button("btn_mythic_hover.png", GOLD_MID, (255, 245, 180, 255), (42, 49, 82, 255), CYAN_MID, CYAN_GLOW, shift=0)

# Pressed: Sunken 1px downward, dark indent
create_button("btn_mythic_pressed.png", GOLD_SHADOW, GOLD_DARK, (16, 18, 30, 255), (10, 12, 20, 255), GOLD_DARK, shift=1)

# Disabled: Dim weathered stone
create_button("btn_mythic_disabled.png", (50, 55, 70, 255), (70, 75, 90, 255), (18, 20, 28, 255), (10, 11, 16, 255), (60, 65, 80, 255), shift=0)

# Tab Active: Gilded crown top, bright body
create_button("btn_tab_active.png", GOLD_MID, GOLD_HIGH, (36, 42, 70, 255), SLATE_BORDER, GOLD_MID, shift=0)

# Tab Inactive: Dark recessed slate
create_button("btn_tab_inactive.png", SLATE_BORDER, SLATE_LIGHT, (16, 18, 30, 255), (8, 9, 15, 255), SLATE_LIGHT, shift=0)

# ==============================================================================
# 7. PROGRESS BARS & SCROLLBAR
# ==============================================================================
# Progress Track (16x10, Margins: 3, 3, 3, 3)
track_img = Image.new("RGBA", (16, 10), (0, 0, 0, 0))
td = ImageDraw.Draw(track_img)
td.rectangle([0, 0, 15, 9], fill=(10, 12, 20, 240))
td.rectangle([0, 0, 15, 9], outline=SLATE_BORDER)
td.line([(1, 1), (14, 1)], fill=(5, 6, 10, 255)) # Inner upper drop shadow
track_img.save(os.path.join(frames_dir, "bar_track_9slice.png"))

# Fill Gold / Honey (16x10, Margins: 2, 2, 2, 2)
fill_gold = Image.new("RGBA", (16, 10), (0, 0, 0, 0))
fgd = ImageDraw.Draw(fill_gold)
fgd.rectangle([1, 1, 14, 8], fill=GOLD_MID)
fgd.line([(1, 1), (14, 1)], fill=GOLD_HIGH)
fgd.line([(1, 8), (14, 8)], fill=GOLD_DARK)
fill_gold.save(os.path.join(frames_dir, "bar_fill_gold.png"))

# Fill Cyan / Mana (16x10, Margins: 2, 2, 2, 2)
fill_cyan = Image.new("RGBA", (16, 10), (0, 0, 0, 0))
fcd = ImageDraw.Draw(fill_cyan)
fcd.rectangle([1, 1, 14, 8], fill=CYAN_MID)
fcd.line([(1, 1), (14, 1)], fill=CYAN_GLOW)
fcd.line([(1, 8), (14, 8)], fill=(20, 80, 110, 255))
fill_cyan.save(os.path.join(frames_dir, "bar_fill_cyan.png"))

# Fill Green / Verdant Laurel (16x10, Margins: 2, 2, 2, 2)
fill_grn = Image.new("RGBA", (16, 10), (0, 0, 0, 0))
fgr = ImageDraw.Draw(fill_grn)
fgr.rectangle([1, 1, 14, 8], fill=(61, 214, 140, 255))
fgr.line([(1, 1), (14, 1)], fill=(140, 245, 185, 255))
fgr.line([(1, 8), (14, 8)], fill=(30, 140, 85, 255))
fill_grn.save(os.path.join(frames_dir, "bar_fill_green.png"))

# Scrollbar Grabber (12x12, Margins: 3, 3, 3, 3)
grabber = Image.new("RGBA", (12, 12), (0, 0, 0, 0))
gbd = ImageDraw.Draw(grabber)
gbd.rectangle([1, 1, 10, 10], fill=GOLD_DARK)
gbd.line([(1, 1), (10, 1)], fill=GOLD_HIGH)
gbd.line([(1, 1), (1, 10)], fill=GOLD_MID)
gbd.line([(10, 1), (10, 10)], fill=GOLD_SHADOW)
gbd.line([(1, 10), (10, 10)], fill=GOLD_SHADOW)
# Center grip ridge
gbd.line([(4, 5), (7, 5)], fill=GOLD_HIGH)
gbd.line([(4, 7), (7, 7)], fill=GOLD_HIGH)
grabber.save(os.path.join(frames_dir, "scrollbar_grabber.png"))

print("All 9-slice frames and button states successfully created!")
