import os
from PIL import Image, ImageDraw

icons_dir = r"c:\Users\netne\Kronos\Kronos Project\kronos-godot\assets\sprites\ui\icons"
os.makedirs(icons_dir, exist_ok=True)

# Colors
GOLD_HI = (255, 235, 140, 255)
GOLD_MID = (245, 195, 66, 255)
GOLD_DARK = (180, 130, 25, 255)
GOLD_SHD = (90, 65, 12, 255)

CYAN_HI = (175, 245, 255, 255)
CYAN_MID = (79, 209, 232, 255)
CYAN_DARK = (28, 115, 140, 255)

ROSE_HI = (255, 190, 210, 255)
ROSE_MID = (245, 95, 130, 255)
ROSE_DARK = (165, 40, 70, 255)

WHITE = (255, 255, 255, 255)
SLATE_DARK = (18, 20, 32, 255)
GREEN_MID = (61, 214, 140, 255)

# ==============================================================================
# 1. COIN (16x16) - Athenian Sun Coin
# ==============================================================================
coin = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
cd = ImageDraw.Draw(coin)
# Outer rim
cd.ellipse([1, 1, 14, 14], fill=GOLD_DARK, outline=GOLD_SHD)
cd.ellipse([2, 2, 13, 13], fill=GOLD_MID)
cd.line([(3, 2), (12, 2)], fill=GOLD_HI)
cd.line([(2, 3), (2, 12)], fill=GOLD_HI)
# Center sun star
cd.rectangle([7, 5, 8, 10], fill=GOLD_HI)
cd.rectangle([5, 7, 10, 8], fill=GOLD_HI)
cd.point((6, 6), fill=GOLD_DARK)
cd.point((9, 6), fill=GOLD_DARK)
cd.point((6, 9), fill=GOLD_DARK)
cd.point((9, 9), fill=GOLD_DARK)
coin.save(os.path.join(icons_dir, "icon_coin.png"))

# ==============================================================================
# 2. ENERGY (16x16) - Zeus Lightning Bolt
# ==============================================================================
energy = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
ed = ImageDraw.Draw(energy)
bolt_pts = [(9, 1), (4, 8), (8, 8), (6, 15), (12, 6), (8, 6)]
ed.polygon(bolt_pts, fill=CYAN_MID, outline=CYAN_DARK)
ed.line([(9, 2), (5, 8)], fill=CYAN_HI)
ed.line([(8, 8), (7, 13)], fill=CYAN_HI)
ed.point((8, 5), fill=WHITE)
energy.save(os.path.join(icons_dir, "icon_energy.png"))

# ==============================================================================
# 3. JOY (16x16) - Aphrodite Rose Crystal Heart
# ==============================================================================
joy = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
jd = ImageDraw.Draw(joy)
# Left lobe
jd.ellipse([2, 3, 8, 9], fill=ROSE_MID)
# Right lobe
jd.ellipse([7, 3, 13, 9], fill=ROSE_MID)
# Bottom tip
jd.polygon([(2, 7), (13, 7), (8, 14)], fill=ROSE_MID)
# Outline & specular
jd.line([(4, 2), (6, 2)], fill=ROSE_HI)
jd.line([(9, 2), (11, 2)], fill=ROSE_HI)
jd.point((4, 4), fill=WHITE)
jd.point((5, 4), fill=WHITE)
joy.save(os.path.join(icons_dir, "icon_joy.png"))

# ==============================================================================
# 4. CROWN (16x16) - Apollo Laurel Sovereign Crown
# ==============================================================================
crown = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
crd = ImageDraw.Draw(crown)
crd.polygon([(2, 12), (13, 12), (14, 5), (10, 8), (8, 3), (6, 8), (1, 5)], fill=GOLD_MID, outline=GOLD_SHD)
crd.line([(3, 11), (12, 11)], fill=GOLD_HI)
crd.rectangle([3, 12, 12, 13], fill=GOLD_DARK)
crd.point((8, 4), fill=WHITE) # Central peak diamond
crd.point((8, 12), fill=ROSE_MID) # Center ruby
crown.save(os.path.join(icons_dir, "icon_crown.png"))

# ==============================================================================
# 5. TIMER CONTROLS (16x16)
# ==============================================================================
# Play
play = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
pd = ImageDraw.Draw(play)
pd.polygon([(4, 3), (13, 8), (4, 13)], fill=GOLD_HI, outline=GOLD_DARK)
pd.line([(4, 4), (11, 8)], fill=WHITE)
play.save(os.path.join(icons_dir, "icon_play.png"))

# Pause
pause = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
pad = ImageDraw.Draw(pause)
pad.rectangle([4, 3, 6, 12], fill=GOLD_HI, outline=GOLD_DARK)
pad.rectangle([9, 3, 11, 12], fill=GOLD_HI, outline=GOLD_DARK)
pause.save(os.path.join(icons_dir, "icon_pause.png"))

# Preset / Astrolabe Gear
preset = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
prd = ImageDraw.Draw(preset)
prd.ellipse([3, 3, 12, 12], fill=GOLD_MID, outline=GOLD_SHD)
prd.rectangle([7, 1, 8, 14], fill=GOLD_HI)
prd.rectangle([1, 7, 14, 8], fill=GOLD_HI)
prd.ellipse([6, 6, 9, 9], fill=SLATE_DARK)
preset.save(os.path.join(icons_dir, "icon_preset.png"))

# Gamepad
game = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
gd = ImageDraw.Draw(game)
gd.rectangle([2, 5, 13, 11], fill=GOLD_DARK, outline=GOLD_SHD)
gd.rectangle([4, 6, 6, 10], fill=GOLD_HI) # D-pad
gd.rectangle([3, 7, 7, 9], fill=GOLD_HI)
gd.point((10, 7), fill=CYAN_HI) # Button A
gd.point((12, 9), fill=ROSE_MID) # Button B
game.save(os.path.join(icons_dir, "icon_game.png"))

# Reset
reset = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
rd = ImageDraw.Draw(reset)
rd.arc([2, 2, 13, 13], 45, 330, fill=GOLD_HI, width=2)
rd.polygon([(11, 2), (14, 5), (10, 6)], fill=GOLD_HI)
reset.save(os.path.join(icons_dir, "icon_reset.png"))

# ==============================================================================
# 6. WINDOW HEADER ICONS (12x12)
# ==============================================================================
# Pin
pin = Image.new("RGBA", (12, 12), (0, 0, 0, 0))
pind = ImageDraw.Draw(pin)
pind.rectangle([3, 2, 8, 4], fill=GOLD_HI)
pind.rectangle([5, 5, 6, 8], fill=GOLD_MID)
pind.line([(5, 9), (5, 11)], fill=GOLD_DARK)
pin.save(os.path.join(icons_dir, "icon_pin.png"))

# Scale
scale = Image.new("RGBA", (12, 12), (0, 0, 0, 0))
scd = ImageDraw.Draw(scale)
scd.rectangle([1, 1, 10, 10], outline=GOLD_MID)
scd.line([(3, 3), (8, 3)], fill=GOLD_HI)
scd.line([(3, 3), (3, 8)], fill=GOLD_HI)
scale.save(os.path.join(icons_dir, "icon_scale.png"))

# Studio (Scroll/Ledger)
studio = Image.new("RGBA", (12, 12), (0, 0, 0, 0))
std = ImageDraw.Draw(studio)
std.rectangle([2, 2, 9, 9], fill=GOLD_MID, outline=GOLD_DARK)
std.line([(4, 4), (7, 4)], fill=WHITE)
std.line([(4, 6), (7, 6)], fill=WHITE)
std.line([(4, 8), (6, 8)], fill=WHITE)
studio.save(os.path.join(icons_dir, "icon_studio.png"))

# Minimize
min_ic = Image.new("RGBA", (12, 12), (0, 0, 0, 0))
mid = ImageDraw.Draw(min_ic)
mid.rectangle([2, 6, 9, 7], fill=GOLD_HI)
min_ic.save(os.path.join(icons_dir, "icon_min.png"))

# Close
close_ic = Image.new("RGBA", (12, 12), (0, 0, 0, 0))
cid = ImageDraw.Draw(close_ic)
cid.line([(2, 2), (9, 9)], fill=ROSE_MID, width=2)
cid.line([(9, 2), (2, 9)], fill=ROSE_MID, width=2)
close_ic.save(os.path.join(icons_dir, "icon_close.png"))

# Chevron Left
ch_l = Image.new("RGBA", (12, 12), (0, 0, 0, 0))
cld = ImageDraw.Draw(ch_l)
cld.line([(7, 2), (3, 6)], fill=GOLD_HI, width=2)
cld.line([(3, 6), (7, 10)], fill=GOLD_HI, width=2)
ch_l.save(os.path.join(icons_dir, "icon_drawer_l.png"))

# Chevron Right
ch_r = Image.new("RGBA", (12, 12), (0, 0, 0, 0))
crd = ImageDraw.Draw(ch_r)
crd.line([(4, 2), (8, 6)], fill=GOLD_HI, width=2)
crd.line([(8, 6), (4, 10)], fill=GOLD_HI, width=2)
ch_r.save(os.path.join(icons_dir, "icon_drawer_r.png"))

# Ledger (16x16)
ledger = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
ld = ImageDraw.Draw(ledger)
ld.rectangle([2, 1, 13, 14], fill=GOLD_DARK, outline=GOLD_SHD)
ld.rectangle([3, 2, 12, 13], fill=(245, 238, 220, 255)) # Parchment
ld.line([(5, 5), (10, 5)], fill=SLATE_DARK)
ld.line([(5, 7), (10, 7)], fill=SLATE_DARK)
ld.line([(5, 9), (9, 9)], fill=SLATE_DARK)
ld.line([(10, 1), (10, 4)], fill=ROSE_MID, width=2) # Ribbon bookmark
ledger.save(os.path.join(icons_dir, "icon_ledger.png"))

# Clock / Sundial (16x16)
clock = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
ckd = ImageDraw.Draw(clock)
ckd.ellipse([1, 1, 14, 14], fill=GOLD_MID, outline=GOLD_SHD)
ckd.ellipse([3, 3, 12, 12], fill=(22, 26, 44, 255))
ckd.line([(8, 4), (8, 8)], fill=GOLD_HI)
ckd.line([(8, 8), (11, 8)], fill=GOLD_HI)
clock.save(os.path.join(icons_dir, "icon_clock.png"))

print("All dedicated mythology pixel icons created successfully!")
